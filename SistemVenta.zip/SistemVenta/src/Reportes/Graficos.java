package Reportes;

import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import javax.swing.JOptionPane;
import modelo.Conexion;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.Dataset;
import org.jfree.data.general.DefaultPieDataset;

public class Graficos {

    public static void GraficarQuincena() {
        Conexion cn = new Conexion();
        Connection con;
        PreparedStatement ps;
        ResultSet rs;

        // Rango de fechas de la quincena actual
        LocalDate hoy = LocalDate.now();
        LocalDate inicio;
        LocalDate fin;

        if (hoy.getDayOfMonth() <= 15) {
            inicio = hoy.withDayOfMonth(1);
            fin = hoy.withDayOfMonth(15);
        } else {
            inicio = hoy.withDayOfMonth(16);
            fin = hoy.withDayOfMonth(hoy.lengthOfMonth());
        }

        try {
            con = cn.getConnection();
            String sql = "SELECT fecha, SUM(total) AS total_dia FROM ventas WHERE fecha BETWEEN ? AND ? GROUP BY fecha ORDER BY fecha";
            ps = con.prepareStatement(sql);
            ps.setString(1, inicio.toString());
            ps.setString(2, fin.toString());
            rs = ps.executeQuery();

            DefaultPieDataset dataset = new DefaultPieDataset();
            
            boolean tieneDatos = false;

            while (rs.next()) {
                String fecha = rs.getString("fecha");
                double total = rs.getDouble("total_dia");
                dataset.setValue(fecha,total);
                tieneDatos = true;
            }
            
            if (!tieneDatos) {
                System.out.println("No hay ventas registradas en la quincena actual");
                return;
            }

            JFreeChart chart = ChartFactory.createPieChart(
                    "Ventas por Dia(Quincena" + inicio + " al " + fin + ")",
                    dataset,
                    true,
                    true,
                    false
            );

            ChartFrame frame = new ChartFrame("Gráfico de Ventas Quincenales", chart);
            frame.setSize(1000, 500);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);

        } catch (SQLException e) {
            System.out.println("Error al graficar quincena: " + e.toString());
        }
    }
    
    public static void GraficarDia(String fecha) {
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    try {
        con = cn.getConnection();
        String sql = "SELECT p.nombre, SUM(d.cantidad * d.precio) AS total_vendido " +
                     "FROM detalle d " +
                     "JOIN productos p ON d.cod_pro = p.codigo " +
                     "JOIN ventas v ON d.id_venta = v.id " +
                     "WHERE v.fecha = ? " +
                     "GROUP BY p.nombre";
        ps = con.prepareStatement(sql);
        ps.setString(1, fecha);
        rs = ps.executeQuery();

        DefaultPieDataset dataset = new DefaultPieDataset();
        boolean hayDatos = false;

        while (rs.next()) {
            String producto = rs.getString("nombre");
            double total = rs.getDouble("total_vendido");
            dataset.setValue(producto, total);
            hayDatos = true;
        }
       

        if (!hayDatos) {
            JOptionPane.showMessageDialog(null, "No hay ventas registradas para la fecha: " + fecha);
            return;
        }

        JFreeChart chart = ChartFactory.createPieChart(
                "Ventas del día: " + fecha,
                dataset,
                true,
                true,
                false
        );

        ChartFrame frame = new ChartFrame("Gráfico de Ventas por Día", chart);
        frame.setSize(800, 500);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

    } catch (SQLException e) {
        System.out.println("Error al generar gráfico del día: " + e.toString());
    }
}

    
}
