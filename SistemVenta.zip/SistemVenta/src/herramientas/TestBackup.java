
package herramientas;


public class TestBackup {
     public static void main(String[] args) {
        herramientas.Backup.generarBackup();
    }
}
