
package herramientas;

import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class Backup {
    public static void generarBackup() {
        String pathBackup = "C:\\backups\\";
        String fecha = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(new Date());
        String nombreArchivo = pathBackup + "backup_sml_" + fecha + ".sql";

        try (FileWriter fw = new FileWriter(nombreArchivo)) {
            fw.write("-- RESPALDO DE BACKUP\n");
            fw.write("-- info\n");
            fw.write("INSERT INTO usuarios (id, nombre, correo, pass, rol) VALUES (1, 'Javier', 'javier@mail.com', '********', 'admin');\n");
            System.out.println("Backup guardado en: " + nombreArchivo);
        } catch (IOException e) {
            System.out.println("Error al realziar el backup");
            e.printStackTrace();
        }
    }

}