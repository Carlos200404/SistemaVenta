package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class VentaDao {

    Connection con;
    Conexion cn = new Conexion();
    PreparedStatement ps;
    ResultSet rs;
    int result;

    public int idVenta() {
        int id = 0;
        String sql = "SELECT MAX(id) FROM ventas";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            if (rs.next()) {
                id = rs.getInt(1);
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return id;
    }

    public int RegistrarVenta(Venta vt) {
        String sql = "INSERT INTO ventas (cliente, vendedor, total, fecha) VALUES (?,?,?,?)";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, vt.getCliente());
            ps.setString(2, vt.getVendedor());
            ps.setDouble(3, vt.getTotal());
            ps.setString(4, vt.getFecha());
            ps.execute();
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return result;
    }

    public int RegistrarDetalle(Detalle dtv) {
        String sql = "INSERT INTO detalle (cod_pro, cantidad, precio, id_venta) VALUES (?,?,?,?)";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, dtv.getCod_pro());
            ps.setInt(2, dtv.getCantidad());
            ps.setDouble(3, dtv.getPrecio());
            ps.setInt(4, dtv.getId());
            ps.execute();

        } catch (SQLException e) {
            System.out.println(e.toString());
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.out.println(e.toString());
            }
        }
        return result;
    }
    
    public boolean ActualizarStock(int cant, String cod){
        String sql = "UPDATE productos SET stock = stock - ? WHERE codigo =?";
        try {
            con =cn.getConnection();
        ps = con.prepareStatement(sql);
        ps.setInt(1,cant);
        ps.setString(2,cod);
        //ps.execute();
        int rowsAffected = ps.executeUpdate();
            System.out.println("Filas actualizadas" + rowsAffected);
            return rowsAffected>0;
           // return true;
        } catch (SQLException e) {
            System.out.println("Error SQL:"+e.toString());
            return false;
        } 
    }
    
    public List ListarVentas() {
        List<Venta> ListaVenta = new ArrayList();
        String sql = "SELECT * FROM ventas";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Venta vent = new Venta();
                vent.setId(rs.getInt("id"));
                vent.setCliente(rs.getString("cliente"));
                vent.setVendedor(rs.getString("vendedor"));
                vent.setTotal(rs.getDouble("total"));
                ListaVenta.add(vent);

            }

        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return ListaVenta;
    }
}
