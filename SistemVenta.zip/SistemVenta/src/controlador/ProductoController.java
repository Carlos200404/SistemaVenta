 
package controlador;

import modelo.ProductosDao;
import modelo.Productos;
import java.util.List;
 
public class ProductoController {
    private final ProductosDao dao = new ProductosDao();

    public Productos buscarPorCodigo(String codigo) {
        return dao.BuscarPro(codigo);
    }

    public List<Productos> listarTodos() {
        return dao.ListarProductos();
    }
}
