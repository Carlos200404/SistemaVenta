
package controlador;

import modelo.LoginDAO;
import modelo.login;
import modelo.Seguridad;

public class AuthController {
    private final LoginDAO loginDao = new LoginDAO();

    public login autenticar(String correo, String passPlano) {
        String passHash = Seguridad.hashSHA256(passPlano);
        return loginDao.log(correo, passHash);
    }
}
