package controlador;

import herramientas.Backup;
import java.io.IOException;

public class BackupController {

    public void generarBackupAhora() {
        Backup.generarBackup();
    }
}
