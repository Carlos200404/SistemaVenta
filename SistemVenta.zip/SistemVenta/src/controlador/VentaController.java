package controlador;

import java.util.List;
import modelo.Venta;
import modelo.Detalle;
import modelo.VentaDao;
import modelo.Productos;
import modelo.ProductosDao;

public class VentaController {

    private final VentaDao dao = new VentaDao();
    ProductosDao prodDao = new ProductosDao();

    public boolean registrarVentaCompleta(Venta venta, List<Detalle> detalles) {
        int id = dao.RegistrarVenta(venta);
        if (id <= 0) {
            return false;
        }

        for (Detalle det : detalles) {
            det.setId(id);
            dao.RegistrarDetalle(det);
            Productos producto = prodDao.BuscarPro(det.getCod_pro());
            int nuevoStock = producto.getStock() - det.getCantidad();
            dao.ActualizarStock(nuevoStock, det.getCod_pro());
        }

        return true;
    }
}
