
package controlador;

import modelo.Cliente;
import modelo.ClienteDao;
import java.util.List;

public class ClienteController {
    private final ClienteDao dao = new ClienteDao();

    public boolean registrar(Cliente cliente) {
        return dao.RegistrarCliente(cliente);
    }

    public List<Cliente> listar() {
        return dao.ListarCliente();
    }
}
